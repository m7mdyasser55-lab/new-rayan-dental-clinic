import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, orderBy, onSnapshot, updateDoc, doc, getCountFromServer } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Appointment } from '../types';
import { 
  Calendar, 
  Clock, 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  MessageSquare, 
  Search, 
  Filter,
  Inbox,
  Mail,
  User as UserIcon,
  Phone,
  BarChart2,
  TrendingUp,
  Activity
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: any;
}

export default function Admin() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'appointments' | 'messages' | 'analytics' | 'settings'>('appointments');
  const [reminderConfig, setReminderConfig] = useState({ reminderHours: 24 });
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    // Sync Appointments
    const pathApts = 'appointments';
    const qApt = query(collection(db, pathApts), orderBy('createdAt', 'desc'));
    const unsubApt = onSnapshot(qApt, (snapshot) => {
      setAppointments(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Appointment)));
      setLoading(false); // always clear loading on first data
    }, (error) => {
      setLoading(false);
      handleFirestoreError(error, OperationType.GET, pathApts);
    });

    // Sync Messages
    const pathMsgs = 'messages';
    const qMsg = query(collection(db, pathMsgs), orderBy('createdAt', 'desc'));
    const unsubMsg = onSnapshot(qMsg, (snapshot) => {
      setMessages(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ContactMessage)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, pathMsgs);
    });

    // Fetch Settings
    const fetchSettings = () => {
      const settingsRef = doc(db, 'settings', 'reminders');
      return onSnapshot(settingsRef, (snap) => {
        if (snap.exists()) {
          setReminderConfig({ reminderHours: snap.data().reminderHours });
        }
      });
    };
    const unsubSettings = fetchSettings();

    return () => {
      unsubApt();
      unsubMsg();
      unsubSettings();
    };
  }, [activeTab]);

  const saveSettings = async () => {
    setSavingSettings(true);
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reminderConfig),
      });
      const data = await response.json();
      if (response.ok) {
        alert('تم حفظ الإعدادات بنجاح');
      } else {
        throw new Error(data.message || 'فشل الحفظ');
      }
    } catch (error) {
      alert(`حدث خطأ أثناء حفظ الإعدادات: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setSavingSettings(false);
    }
  };

  const triggerReminders = async () => {
    try {
      const response = await fetch('/api/admin/trigger-reminders', { method: 'POST' });
      const data = await response.json();
      if (response.ok) {
        alert('تم تشغيل فحص التذكيرات');
      } else {
        throw new Error(data.message || 'فشل تشغيل التذكيرات');
      }
    } catch (error) {
      alert(`حدث خطأ: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const updateStatus = async (id: string, status: string) => {
    const path = `appointments/${id}`;
    try {
      await updateDoc(doc(db, 'appointments', id), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const filteredAppointments = appointments.filter(a => {
    const matchesFilter = filter === 'all' || a.status === filter;
    const matchesSearch = a.patientName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          a.patientPhone.includes(searchTerm);
    return matchesFilter && matchesSearch;
  });

  const stats = {
    totalApts: appointments.length,
    pendingApts: appointments.filter(a => a.status === 'pending').length,
    totalMsgs: messages.length,
    todayApts: appointments.filter(a => a.date === new Date().toISOString().split('T')[0]).length
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12" dir="rtl">
      {/* Header & Stats */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-8">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight flex items-center">
            لوحة التحكم <span className="mr-3 text-teal-600 bg-teal-50 text-base px-4 py-1 rounded-full font-bold">المسؤول</span>
          </h1>
          <p className="text-gray-500 mt-2">إدارة الحجوزات والتواصل مع العملاء من مكان واحد.</p>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 w-full lg:w-auto">
          {[
            { label: 'إجمالي الحجوزات', value: stats.totalApts, color: 'text-teal-600' },
            { label: 'حجوزات معلقة', value: stats.pendingApts, color: 'text-yellow-600' },
            { label: 'رسائل جديدة', value: stats.totalMsgs, color: 'text-blue-600' },
            { label: 'مواعيد اليوم', value: stats.todayApts, color: 'text-purple-600' }
          ].map((stat, i) => (
            <div key={i} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm text-center">
              <p className="text-xs font-bold text-gray-400 mb-1">{stat.label}</p>
              <p className={`text-2xl font-black ${stat.color}`}>{stat.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-8 gap-8">
        {(['appointments', 'messages', 'analytics', 'settings'] as const).map((tabId) => {
          const names = {
            appointments: 'الحجوزات',
            messages: 'رسائل التواصل',
            analytics: 'التحليلات',
            settings: 'الإعدادات'
          };
          const isActive = activeTab === tabId;
          
          return (
            <button
              key={tabId}
              id={tabId === 'appointments' ? 'appointments-tab' : undefined}
              onClick={() => setActiveTab(tabId)}
              className={`pb-4 px-1 font-black text-lg transition-all relative flex items-center gap-2 ${
                isActive ? 'text-teal-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              {names[tabId]}
              {tabId === 'messages' && stats.totalMsgs > 0 && (
                <span className="bg-teal-500 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full shrink-0">
                  {stats.totalMsgs}
                </span>
              )}
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-600 rounded-full"
                  transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                />
              )}
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <RefreshCw className="h-10 w-10 text-teal-500 animate-spin" />
        </div>
      ) : (
        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {activeTab === 'appointments' ? (
              <motion.div
                key="apts"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                {/* Filters & Search */}
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-2">
                  <div className="flex overflow-x-auto pb-2 scrollbar-hide gap-3 w-full md:w-auto">
                    {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map((f) => (
                      <button
                        key={f}
                        onClick={() => setFilter(f)}
                        className={`px-6 py-2.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                          filter === f ? 'bg-teal-500 text-white shadow-lg shadow-teal-200' : 'bg-white text-gray-400 border border-gray-100 hover:border-teal-200'
                        }`}
                      >
                        {f === 'all' ? 'الكل' : f === 'pending' ? 'قيد الانتظار' : f === 'confirmed' ? 'مؤكدة' : f === 'completed' ? 'مكتملة' : 'ملغاة'}
                      </button>
                    ))}
                  </div>

                  <div className="relative w-full md:w-80">
                    <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="بحث باسم المريض أو الهاتف..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-4 pr-12 py-3 bg-white border border-gray-100 rounded-2xl focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all shadow-sm"
                    />
                  </div>
                </div>

                {filteredAppointments.length === 0 ? (
                  <div className="bg-white p-20 rounded-[3rem] text-center border border-dashed border-gray-200 text-gray-400">
                    لا يوجد مواعيد في هذا القسم حالياً.
                  </div>
                ) : (
                  filteredAppointments.map((apt) => (
                    <div
                      key={apt.id}
                      className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col lg:flex-row lg:items-center justify-between gap-8 group hover:border-teal-200 transition-all"
                    >
                      <div className="flex items-center gap-6">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${
                          apt.status === 'confirmed' ? 'bg-blue-50 text-blue-600' : 
                          apt.status === 'completed' ? 'bg-green-50 text-green-600' : 
                          apt.status === 'cancelled' ? 'bg-red-50 text-red-600' : 'bg-yellow-50 text-yellow-600'
                        }`}>
                          <Calendar className="h-6 w-6" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-3">
                            <h3 className="text-xl font-bold text-gray-900">{apt.patientName}</h3>
                            {apt.date === new Date().toISOString().split('T')[0] && (
                              <span className="bg-orange-100 text-orange-600 text-[10px] px-2 py-0.5 rounded-full font-black animate-pulse">
                                الموعد اليوم
                              </span>
                            )}
                          </div>
                          <div className="flex items-center text-gray-500 text-sm gap-4">
                            <span className="flex items-center"><Phone className="h-4 w-4 ml-1" /> {apt.patientPhone}</span>
                            <span className="font-bold text-teal-600">| {apt.serviceName}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-10 py-4 px-8 bg-gray-50/50 rounded-2xl lg:bg-transparent lg:border-x lg:border-gray-100">
                        <div className="text-center">
                          <p className="text-[10px] text-gray-400 uppercase font-black mb-1">التاريخ</p>
                          <p className="font-bold text-gray-700">{apt.date}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-[10px] text-gray-400 uppercase font-black mb-1">الوقت</p>
                          <p className="font-bold text-gray-700">{apt.time}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-center lg:self-auto">
                        {apt.status === 'pending' && (
                          <>
                            <button
                              onClick={() => updateStatus(apt.id!, 'confirmed')}
                              className="px-6 py-3 bg-teal-500 text-white rounded-xl font-bold hover:bg-teal-600 transition-all shadow-lg shadow-teal-100"
                            >
                              تأكيد
                            </button>
                            <button
                              onClick={() => updateStatus(apt.id!, 'cancelled')}
                              className="p-3 bg-red-50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all"
                            >
                              <XCircle className="h-6 w-6" />
                            </button>
                          </>
                        )}
                        {apt.status === 'confirmed' && (
                          <button
                            onClick={() => updateStatus(apt.id!, 'completed')}
                            className="px-6 py-3 bg-gray-900 text-white rounded-xl font-bold hover:bg-black transition-all"
                          >
                            اكتملت الزيارة
                          </button>
                        )}
                        {apt.status === 'completed' && <span className="text-green-500 font-bold px-4 py-2 bg-green-50 rounded-lg">تمت المعالجة</span>}
                        {apt.status === 'cancelled' && <span className="text-red-500 font-bold px-4 py-2 bg-red-50 rounded-lg">تم الإلغاء</span>}
                      </div>
                    </div>
                  ))
                )}
              </motion.div>
            ) : activeTab === 'messages' ? (
              <motion.div
                key="msgs"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
              >
                {messages.length === 0 ? (
                  <div className="col-span-full bg-white p-20 rounded-[3rem] text-center border border-dashed border-gray-200 text-gray-400">
                    لا يوجد استفسارات حالياً.
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div key={msg.id} className="bg-white p-8 rounded-3xl border border-gray-100 hover:shadow-xl transition-all space-y-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center">
                            <UserIcon className="h-6 w-6" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">{msg.name}</h3>
                            <p className="text-xs text-gray-400">{msg.email}</p>
                          </div>
                        </div>
                        <span className="text-[10px] text-gray-300">
                          {msg.createdAt?.toDate?.().toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-xl relative">
                        <Inbox className="absolute -top-3 -right-3 text-teal-100 h-8 w-8" />
                        <p className="text-gray-600 text-sm leading-relaxed relative z-10">{msg.message}</p>
                      </div>
                      <a 
                        href={`mailto:${msg.email}`}
                        className="flex items-center justify-center gap-2 p-3 bg-teal-500 text-white rounded-xl font-bold hover:bg-teal-600 transition-all"
                      >
                        <Mail className="h-4 w-4" />
                        رد عبر البريد
                      </a>
                    </div>
                  ))
                )}
              </motion.div>
            ) : activeTab === 'settings' ? (
              <motion.div
                key="settings"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-2xl mx-auto space-y-8"
              >
                <div className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">إعدادات التذكير</h3>
                    <p className="text-gray-500">قم بتكوين متى وكيف يتم إرسال تذكيرات المواعيد للمرضى.</p>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">وقت التذكير (قبل الموعد بـ ساعة)</label>
                      <input 
                        type="number" 
                        value={reminderConfig.reminderHours}
                        onChange={(e) => setReminderConfig({ ...reminderConfig, reminderHours: parseInt(e.target.value) })}
                        className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                        placeholder="مثلاً: 24"
                      />
                      <p className="text-xs text-gray-400">سيتم إرسال بريد إلكتروني تذكيري للمريض قبل موعده بالوقت المحدد.</p>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4 pt-4">
                      <button 
                        onClick={saveSettings}
                        disabled={savingSettings}
                        className="flex-1 px-8 py-4 bg-teal-500 text-white rounded-2xl font-bold hover:bg-teal-600 transition-all shadow-lg shadow-teal-100 disabled:opacity-50"
                      >
                        {savingSettings ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
                      </button>
                      <button 
                        onClick={triggerReminders}
                        className="flex-1 px-8 py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-black transition-all"
                      >
                        تشغيل فحص التذكيرات يدوياً
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-8 rounded-[2rem] border border-blue-100">
                  <h4 className="font-bold text-blue-900 mb-2">ملاحظة تقنية</h4>
                  <p className="text-sm text-blue-700 leading-relaxed">
                    يتم تشغيل فحص التذكيرات تلقائياً مرة كل ساعة عبر النظام (Cron Job). يرجى التأكد من تكوين متغيرات بيئة البريد الإلكتروني (EMAIL_USER, EMAIL_PASS) في لوحة التحكم لإتمام الإرسال الفعلي.
                  </p>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="analytics"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Appointment Trends */}
                  <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                    <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                      <TrendingUp className="ml-2 text-teal-500 h-5 w-5" />
                      نشاط المواعيد (آخر 7 أيام)
                    </h3>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={Object.entries(
                          appointments.reduce((acc: any, curr) => {
                            const date = curr.date;
                            acc[date] = (acc[date] || 0) + 1;
                            return acc;
                          }, {})
                        ).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date)).slice(-7)}>
                          <defs>
                            <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.1}/>
                              <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                            labelStyle={{ fontWeight: 'bold', marginBottom: '4px' }}
                          />
                          <Area type="monotone" dataKey="count" stroke="#14b8a6" strokeWidth={3} fillOpacity={1} fill="url(#colorCount)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Services Breakdown */}
                  <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                    <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                      <BarChart2 className="ml-2 text-blue-500 h-5 w-5" />
                      توزيع الخدمات
                    </h3>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={Object.entries(
                          appointments.reduce((acc: any, curr) => {
                            const name = curr.serviceName;
                            acc[name] = (acc[name] || 0) + 1;
                            return acc;
                          }, {})
                        ).map(([name, value]) => ({ name, value: value as number })).sort((a, b) => b.value - a.value)}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#9ca3af' }} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
                          <Tooltip 
                            cursor={{ fill: '#f8fafc' }}
                            contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                          />
                          <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Status Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-teal-50 p-6 rounded-3xl border border-teal-100">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 bg-teal-500 text-white rounded-xl flex items-center justify-center">
                        <CheckCircle className="h-5 w-5" />
                      </div>
                      <h4 className="font-bold text-teal-900">معدل الإنجاز</h4>
                    </div>
                    <p className="text-3xl font-black text-teal-600">
                      {appointments.length > 0 ? Math.round((appointments.filter(a => a.status === 'completed').length / appointments.length) * 100) : 0}%
                    </p>
                    <p className="text-sm text-teal-500 mt-1">من إجمالي الحجوزات المستلمة</p>
                  </div>

                  <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 bg-blue-500 text-white rounded-xl flex items-center justify-center">
                        <Activity className="h-5 w-5" />
                      </div>
                      <h4 className="font-bold text-blue-900">المواعيد النشطة</h4>
                    </div>
                    <p className="text-3xl font-black text-blue-600">
                      {appointments.filter(a => a.status === 'confirmed').length}
                    </p>
                    <p className="text-sm text-blue-500 mt-1">مواعيد مؤكدة للمستقبل</p>
                  </div>

                  <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 bg-red-500 text-white rounded-xl flex items-center justify-center">
                        <XCircle className="h-5 w-5" />
                      </div>
                      <h4 className="font-bold text-red-900">معدل الإلغاء</h4>
                    </div>
                    <p className="text-3xl font-black text-red-600">
                      {appointments.length > 0 ? Math.round((appointments.filter(a => a.status === 'cancelled').length / appointments.length) * 100) : 0}%
                    </p>
                    <p className="text-sm text-red-500 mt-1">نسبة الحجوزات الملغاة</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
