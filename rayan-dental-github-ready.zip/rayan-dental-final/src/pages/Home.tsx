import React from 'react';
import { motion } from 'motion/react';
import { Shield, Sparkles, Clock, Heart, ArrowLeft, Star, Quote, Instagram, Facebook, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';
import Gallery from '../components/Gallery';
import ContactForm from '../components/ContactForm';
import doctorImage from '../assets/images/regenerated_image_1778847123393.jpg';

const services = [
  {
    title: 'تبييض الأسنان',
    description: 'احصل على ابتسامة مشرقة وجذابة باستخدام أحدث تقنيات الليزر لتبييض الأسنان بأمان وفعالية.',
    icon: <Sparkles className="h-8 w-8 text-teal-500" />,
    image: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=400'
  },
  {
    title: 'زراعة الأسنان',
    description: 'استعد وظيفة ومظهر أسنانك الطبيعية مع خدمات زراعة الأسنان المتطورة بأيدي خبراء متخصصين.',
    icon: <Shield className="h-8 w-8 text-teal-500" />,
    image: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&q=80&w=400'
  },
  {
    title: 'تقويم الأسنان',
    description: 'حلول متكاملة لتعديل اصطفاف الأسنان باستخدام التقويم الشفاف والعادي لجميع الفئات العمرية.',
    icon: <Clock className="h-8 w-8 text-teal-500" />,
    image: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&q=80&w=400'
  },
  {
    title: 'طب أسنان الأطفال',
    description: 'عناية خاصة ولطيفة بأسنان أطفالكم في بيئة مريحة وودودة تجعل زيارة الطبيب تجربة ممتعة.',
    icon: <Heart className="h-8 w-8 text-teal-500" />,
    image: 'https://images.unsplash.com/photo-1460309139523-beea7c6742a7?auto=format&fit=crop&q=80&w=400'
  }
];

const testimonials = [
  {
    name: 'أحمد القحطاني',
    content: 'تجربة رائعة جداً، الطاقم محترف والعيادة مجهزة بأحدث الوسائل. أنصح بها بشدة لمن يبحث عن الجودة.',
    rating: 5
  },
  {
    name: 'سارة محمد',
    content: 'خدمة تبييض الأسنان كانت مذهلة، لم أشعر بأي ألم والنتائج كانت فورية. شكراً جزيلاً للفريق.',
    rating: 5
  },
  {
    name: 'خالد العنزي',
    content: 'أفضل عيادة أسنان زرتها على الإطلاق. اهتمام بالتفاصيل ونظافة فائقة للعيادة.',
    rating: 5
  }
];

export default function Home() {
  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=2000"
            alt="Clinic Interior"
            className="w-full h-full object-cover brightness-50"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-black/60 to-transparent" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right text-white space-y-8">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-extrabold leading-tight">
              نحن <span className="text-teal-400">صناع الابتسامة</span>
            </h1>
            <p className="text-xl md:text-2xl mt-6 text-gray-200 max-w-2xl ml-auto">
              عيادة د/ محمد ريان ترحب بكم. نقدم رعاية متكاملة لأسنانكم في قلب الإسكندرية باستخدام أحدث التقنيات العالمية.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6 sm:space-x-reverse justify-end">
              <Link
                to="/booking"
                className="inline-flex items-center justify-center px-8 py-4 bg-teal-500 text-white rounded-full text-lg font-bold hover:bg-teal-600 transition-all shadow-xl shadow-teal-500/20 group"
              >
                <span>حجز موعد إلكتروني</span>
                <ArrowLeft className="mr-2 h-5 w-5 group-hover:-translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/#services"
                className="inline-flex items-center justify-center px-8 py-4 bg-white/10 backdrop-blur-md text-white border border-white/30 rounded-full text-lg font-bold hover:bg-white/20 transition-all"
              >
                اكتشف خدماتنا
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="text-center mb-16 space-y-4">
          <span className="text-teal-600 font-bold uppercase tracking-wider">ماذا نقدم؟</span>
          <h2 className="text-4xl font-extrabold text-gray-900">خدماتنا المتميزة</h2>
          <div className="w-20 h-1.5 bg-teal-500 mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm hover:shadow-xl transition-all group"
            >
              <div className="mb-6 p-4 bg-teal-50 rounded-2xl inline-block group-hover:scale-110 transition-transform">
                {service.icon}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed mb-6">{service.description}</p>
              <Link to="/booking" className="text-teal-600 font-bold flex items-center group-hover:underline">
                حجز الآن <ArrowLeft className="mr-2 h-4 w-4" />
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Biography Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-[3rem] p-8 md:p-16 border border-gray-100 shadow-2xl flex flex-col lg:flex-row gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="lg:w-1/2 relative"
          >
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-teal-100 rounded-full -z-0" />
            <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-gray-100 rounded-[3rem] -z-0" />
            <img 
              src={doctorImage} 
              alt="Dr. Mohamed Rayan" 
              className="relative z-10 w-full rounded-[2.5rem] shadow-2xl object-cover h-[500px]"
            />
          </motion.div>
          
          <div className="lg:w-1/2 space-y-8 text-right">
            <div className="space-y-4">
              <span className="text-teal-600 font-bold tracking-widest uppercase">مرحباً بكم في عيادتنا</span>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-tight">
                دكتور <span className="text-teal-500">محمد ريان</span>
              </h2>
              <p className="text-xl text-gray-500 font-medium italic">أخصائي طب وجراحة الفم والأسنان</p>
            </div>
            
            <p className="text-lg text-gray-600 leading-relaxed">
              يؤمن الدكتور محمد ريان بأن الابتسامة هي لغة العالم، ومن هذا المنطلق كرّس مسيرته المهنية التي تمتد لأكثر من 15 عاماً في الإسكندرية لخدمة مرضاه بكل إخلاص. يجمع في أسلوبه العلاجي بين اللمسة الفنية الدقيقة وأحدث ما توصل إليه العلم في مجال تجميل وزراعة الأسنان.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 border-r-4 border-teal-500 pr-3">رؤية حديثة</h4>
                <p className="text-sm text-gray-500">نستخدم أحدث أجهزة الأشعة والليزر لضمان تشخيص دقيق وعلاج مريح.</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 border-r-4 border-teal-500 pr-3">أمان وثقة</h4>
                <p className="text-sm text-gray-500">نطبق صارم بروتوكولات التعقيم العالمية لسلامتكم وسلامة عائلاتكم.</p>
              </div>
            </div>

            <div className="pt-6">
              <Link to="/booking" className="inline-flex items-center px-8 py-4 bg-gray-900 text-white rounded-full font-bold hover:bg-black transition-all">
                استشارة مع الدكتور <ArrowLeft className="mr-3 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-teal-600 py-20 text-white overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
            <div className="space-y-2">
              <span className="text-5xl font-black">+15</span>
              <p className="text-teal-100 font-medium text-lg">سنة خبرة</p>
            </div>
            <div className="space-y-2">
              <span className="text-5xl font-black">+5000</span>
              <p className="text-teal-100 font-medium text-lg">مريض سعيد</p>
            </div>
            <div className="space-y-2">
              <span className="text-5xl font-black">+20</span>
              <p className="text-teal-100 font-medium text-lg">جائزة دولية</p>
            </div>
            <div className="space-y-2">
              <span className="text-5xl font-black">24/7</span>
              <p className="text-teal-100 font-medium text-lg">دعم وحالات طارئة</p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <Gallery />

      {/* Testimonials */}
      <section id="testimonials" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="bg-gray-50 rounded-[3rem] p-12 md:p-20 relative overflow-hidden">
          <Quote className="absolute top-10 right-10 text-teal-100 h-40 w-40 -z-0" />
          <div className="relative z-10 text-center space-y-12">
            <h2 className="text-4xl font-extrabold text-gray-900">آراء مرضانا هي فخرنا</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((t, index) => (
                <div key={index} className="bg-white p-8 rounded-2xl shadow-sm space-y-4">
                  <div className="flex justify-center space-x-1 space-x-reverse">
                    {[...Array(t.rating).keys()].map(i => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 italic leading-relaxed">"{t.content}"</p>
                  <p className="font-bold text-teal-600">{t.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 scroll-mt-24">
        <div className="text-center mb-16 space-y-4">
          <span className="text-teal-600 font-bold uppercase tracking-wider">تواصل معنا</span>
          <h2 className="text-4xl font-extrabold text-gray-900">نحن هنا للإجابة على استفساراتك</h2>
          <div className="w-20 h-1.5 bg-teal-500 mx-auto rounded-full" />
        </div>
        <ContactForm />
      </section>

      {/* Contact CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gray-900 rounded-[3rem] p-12 flex flex-col md:flex-row items-center justify-between text-white space-y-8 md:space-y-0">
          <div className="space-y-4 text-center md:text-right">
            <h2 className="text-4xl font-extrabold">هل لديك استفسار؟</h2>
            <p className="text-gray-400 text-xl">تواصل معنا اليوم أو قم بحجز موعد للفحص المجاني.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 mb-8 md:mb-0">
            <div className="flex space-x-4 space-x-reverse justify-center md:justify-start mb-6 md:mb-0 md:ml-8">
              <a 
                href="https://www.facebook.com/share/1CjdFykLV3/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#1877F2] transition-colors border border-white/20"
              >
                <Facebook className="h-6 w-6" />
              </a>
              <a 
                href="https://www.instagram.com/rayan_dental_care?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#E4405F] transition-colors border border-white/20"
              >
                <Instagram className="h-6 w-6" />
              </a>
              <a 
                href="https://wa.me/201550809980" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#25D366] transition-colors border border-white/20"
              >
                <MessageSquare className="h-6 w-6" />
              </a>
            </div>
            <div className="flex space-x-4 space-x-reverse">
              <Link to="/booking" className="bg-teal-500 px-10 py-4 rounded-full font-bold hover:bg-teal-600 transition-colors">
                حجز موعد
              </Link>
              <a href="tel:01550809980" className="bg-white/10 px-10 py-4 rounded-full font-bold hover:bg-white/20 transition-colors">
                اتصل بنا
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
