import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar as CalendarIcon, Clock, User, Phone, FileText, CheckCircle2, X } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

const services = [
  { id: 'whitening', name: 'تبييض الأسنان', duration: '60 دقيقة' },
  { id: 'implants', name: 'زراعة الأسنان', duration: '90 دقيقة' },
  { id: 'ortho', name: 'تقويم الأسنان', duration: '45 دقيقة' },
  { id: 'peds', name: 'طب أسنان الأطفال', duration: '30 دقيقة' },
  { id: 'cleaning', name: 'تنظيف وتلميع', duration: '30 دقيقة' },
];

const timeSlots = [
  '03:00 م', '03:30 م', '04:00 م', '04:30 م', '05:00 م', '05:30 م',
  '06:00 م', '06:30 م', '07:00 م', '07:30 م', '08:00 م', '08:30 م',
];

// Validate Egyptian phone numbers
const isValidEgyptianPhone = (phone: string) =>
  /^(010|011|012|015)\d{8}$/.test(phone.replace(/\s/g, ''));

export default function Booking() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({
    serviceId: '',
    date: '',
    time: '',
    notes: '',
    patientName: profile?.name || '',
    patientPhone: profile?.phone || '',
  });

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.patientName.trim()) newErrors.patientName = 'الاسم مطلوب';
    if (!isValidEgyptianPhone(formData.patientPhone))
      newErrors.patientPhone = 'يرجى إدخال رقم مصري صحيح (010/011/012/015)';
    if (!formData.serviceId) newErrors.serviceId = 'يرجى اختيار خدمة';
    if (!formData.date) newErrors.date = 'التاريخ مطلوب';
    if (!formData.time) newErrors.time = 'الوقت مطلوب';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const service = services.find(s => s.id === formData.serviceId);
      // Write directly to Firestore — works on both server & static deploys
      await addDoc(collection(db, 'appointments'), {
        patientId: user?.uid || 'anonymous',
        patientName: formData.patientName.trim(),
        patientPhone: formData.patientPhone.replace(/\s/g, ''),
        patientEmail: user?.email || '',
        serviceId: formData.serviceId,
        serviceName: service?.name || '',
        date: formData.date,
        time: formData.time,
        notes: formData.notes.trim(),
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setSuccess(true);
      setTimeout(() => navigate('/'), 3000);
    } catch (error) {
      console.error('Booking error:', error);
      alert('عذراً، حدث خطأ أثناء محاولة الحجز. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-12 rounded-[2rem] shadow-2xl text-center space-y-6 max-w-lg w-full border border-teal-50 relative"
        >
          <button
            onClick={() => navigate('/')}
            className="absolute top-6 left-6 p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-all"
            aria-label="إغلاق"
          >
            <X className="h-6 w-6" />
          </button>
          <div className="w-20 h-20 bg-teal-100 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="h-12 w-12 text-teal-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900">تم طلب الحجز بنجاح!</h2>
          <p className="text-gray-600 text-lg">
            سنتواصل معك عبر الهاتف لتأكيد الموعد قريباً. سيتم تحويلك للصفحة الرئيسية...
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="max-w-4xl mx-auto px-4 py-16 relative">
      <button
        onClick={() => navigate('/')}
        className="absolute top-8 left-8 z-10 p-2 bg-gray-100 text-gray-400 rounded-full hover:scale-110 transition-all"
        aria-label="إغلاق"
      >
        <X className="h-6 w-6" />
      </button>

      <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden flex flex-col md:flex-row border border-gray-100">
        {/* Sidebar */}
        <div className="bg-teal-600 md:w-1/3 p-12 text-white space-y-8 flex flex-col justify-center">
          <h1 className="text-4xl font-extrabold leading-tight">ابدأ رحلتك نحو ابتسامة أجمل</h1>
          <p className="text-teal-50 opacity-90 text-lg">
            قم بتعبئة البيانات وسيقوم فريقنا بمراجعة الموعد والتواصل معك خلال دقائق.
          </p>
          <div className="space-y-4">
            <div className="flex items-center space-x-3 space-x-reverse text-teal-100">
              <CalendarIcon className="h-6 w-6" />
              <span>اختر اليوم المناسب</span>
            </div>
            <div className="flex items-center space-x-3 space-x-reverse text-teal-100">
              <Clock className="h-6 w-6" />
              <span>اختر الوقت المتاح</span>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="md:w-2/3 p-12">
          <form onSubmit={handleSubmit} noValidate className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center">
                  <User className="h-4 w-4 ml-2 text-teal-500" /> الاسم بالكامل *
                </label>
                <input
                  type="text"
                  autoComplete="name"
                  value={formData.patientName}
                  onChange={e => setFormData({ ...formData, patientName: e.target.value })}
                  className={`w-full px-4 py-3 bg-gray-50 rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none border-2 ${errors.patientName ? 'border-red-300' : 'border-transparent'}`}
                  placeholder="محمد أحمد"
                />
                {errors.patientName && <p className="text-xs text-red-500">{errors.patientName}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center">
                  <Phone className="h-4 w-4 ml-2 text-teal-500" /> رقم الهاتف *
                </label>
                <input
                  type="tel"
                  autoComplete="tel"
                  value={formData.patientPhone}
                  onChange={e => setFormData({ ...formData, patientPhone: e.target.value })}
                  className={`w-full px-4 py-3 bg-gray-50 rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none border-2 ${errors.patientPhone ? 'border-red-300' : 'border-transparent'}`}
                  placeholder="010 0000 0000"
                />
                {errors.patientPhone && <p className="text-xs text-red-500">{errors.patientPhone}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">نوع الخدمة المطلوبة *</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {services.map(s => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, serviceId: s.id })}
                    className={`p-4 rounded-xl text-right border-2 transition-all ${
                      formData.serviceId === s.id
                        ? 'border-teal-500 bg-teal-50 text-teal-700 shadow-inner'
                        : 'border-gray-100 bg-gray-50 hover:border-teal-200 text-gray-600'
                    }`}
                  >
                    <div className="font-bold">{s.name}</div>
                    <div className="text-xs opacity-70">المدة المتوقعة: {s.duration}</div>
                  </button>
                ))}
              </div>
              {errors.serviceId && <p className="text-xs text-red-500">{errors.serviceId}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">التاريخ *</label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={formData.date}
                  onChange={e => {
                    const date = new Date(e.target.value);
                    if (date.getUTCDay() === 5) {
                      setErrors(prev => ({ ...prev, date: 'الجمعة عطلة رسمية، يرجى اختيار يوم آخر' }));
                      setFormData({ ...formData, date: '' });
                    } else {
                      setErrors(prev => ({ ...prev, date: '' }));
                      setFormData({ ...formData, date: e.target.value });
                    }
                  }}
                  className={`w-full px-4 py-3 bg-gray-50 rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none border-2 ${errors.date ? 'border-red-300' : 'border-transparent'}`}
                />
                {errors.date
                  ? <p className="text-xs text-red-500">{errors.date}</p>
                  : <p className="text-[10px] text-gray-400">مواعيد العمل: السبت - الخميس (٣م - ٩م)</p>
                }
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">الوقت *</label>
                <select
                  value={formData.time}
                  onChange={e => setFormData({ ...formData, time: e.target.value })}
                  className={`w-full px-4 py-3 bg-gray-50 rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none border-2 ${errors.time ? 'border-red-300' : 'border-transparent'}`}
                >
                  <option value="">اختر الوقت...</option>
                  {timeSlots.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
                {errors.time && <p className="text-xs text-red-500">{errors.time}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 flex items-center">
                <FileText className="h-4 w-4 ml-2 text-teal-500" /> ملاحظات إضافية
              </label>
              <textarea
                value={formData.notes}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-4 py-3 bg-gray-50 border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none resize-none"
                placeholder="أي أعراض أو طلبات خاصة..."
              />
            </div>

            <button
              disabled={loading}
              type="submit"
              className="w-full bg-teal-600 text-white py-5 rounded-2xl font-bold text-xl hover:bg-teal-700 transition-all shadow-xl shadow-teal-500/20 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'جاري إرسال الطلب...' : 'تأكيد طلب الحجز'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
