import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { useNavigate, useSearchParams } from 'react-router-dom';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const redirect = searchParams.get('redirect') || '/';

  const handleGoogleLogin = async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        const role = user.email === 'm7mdyasser55@gmail.com' ? 'admin' : 'patient';
        await setDoc(docRef, {
          uid: user.uid,
          name: user.displayName || 'مريض جديد',
          email: user.email,
          role: role,
          createdAt: serverTimestamp(),
        });
      }
      
      const finalProfile = (await getDoc(docRef)).data();
      const finalRedirect = finalProfile?.role === 'admin' ? '/admin' : redirect;
      navigate(finalRedirect);
    } catch (error) {
      console.error(error);
      alert('فشل تسجيل الدخول. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 bg-gray-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white p-12 rounded-[2.5rem] shadow-2xl border border-gray-100 text-center space-y-8"
      >
        <div className="w-20 h-20 bg-teal-500 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-teal-200">
          <span className="text-white text-3xl font-black">D</span>
        </div>
        <div className="space-y-4">
          <h1 className="text-3xl font-extrabold text-gray-900">مرحباً بك في عيادتنا</h1>
          <p className="text-gray-500">قم بتسجيل الدخول لإدارة مواعيدك والوصول إلى سجلاتك الطبية بكل سهولة.</p>
        </div>

        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full flex items-center justify-center space-x-4 space-x-reverse bg-white border-2 border-gray-100 py-4 rounded-2xl font-bold text-gray-700 hover:bg-gray-50 hover:border-teal-200 transition-all active:scale-95 disabled:opacity-50"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/pwa_static_icons/google.svg" alt="Google" className="w-6 h-6" />
          <span>{loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول بواسطة Google'}</span>
        </button>

        <div className="pt-6 border-t border-gray-50 text-xs text-gray-400">
          من خلال تسجيل الدخول، فإنك توافق على شروط الخدمة وسياسة الخصوصية الخاصة بنا.
        </div>
      </motion.div>
    </div>
  );
}
