import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, where, orderBy, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import { Appointment } from '../types';
import { Calendar, Clock, Trash2, FileText, ChevronLeft } from 'lucide-react';

export default function Portal() {
  const { user, profile } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'appointments'),
      where('patientId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    return onSnapshot(q, (snapshot) => {
      setAppointments(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Appointment)));
      setLoading(false);
    });
  }, [user]);

  const cancelAppointment = async (id: string) => {
    if (!window.confirm('هل أنت متأكد من إلغاء الموعد؟')) return;
    const path = `appointments/${id}`;
    try {
      await updateDoc(doc(db, 'appointments', id), { status: 'cancelled' });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-blue-100 text-blue-700';
      case 'completed': return 'bg-green-100 text-green-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-yellow-100 text-yellow-700';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'confirmed': return 'مؤكد';
      case 'completed': return 'مكتمل';
      case 'cancelled': return 'ملغى';
      default: return 'قيد المراجعة';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-12 flex flex-col md:flex-row md:items-end md:justify-between space-y-6 md:space-y-0">
        <div className="space-y-2 text-right">
          <h1 className="text-4xl font-extrabold text-gray-900">أهلاً بك، {profile?.name}</h1>
          <p className="text-gray-500 text-lg">هنا يمكنك متابعة مواعيدك القادمة وسجلك الطبي.</p>
        </div>
        <div className="bg-teal-50 px-6 py-4 rounded-2xl flex items-center space-x-4 space-x-reverse">
          <div className="w-12 h-12 bg-teal-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
            {profile?.name?.[0]}
          </div>
          <div>
            <p className="font-bold text-teal-900">{profile?.email}</p>
            <p className="text-sm text-teal-700">مريض مسجل</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <h2 className="text-2xl font-bold flex items-center">
            مواعيدي <span className="mr-3 bg-gray-100 text-gray-600 text-sm py-1 px-3 rounded-full">{appointments.length}</span>
          </h2>

          {loading ? (
            <div className="space-y-4">
              {[1, 2].map(i => <div key={i} className="h-40 bg-gray-100 animate-pulse rounded-3xl" />)}
            </div>
          ) : appointments.length === 0 ? (
            <div className="bg-white p-20 rounded-[3rem] border border-dashed border-gray-200 text-center space-y-6">
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                <Calendar className="h-10 w-10 text-gray-300" />
              </div>
              <p className="text-gray-400 text-lg">لم تقم بحجز أي مواعيد بعد.</p>
              <button onClick={() => window.location.href='/booking'} className="bg-teal-500 text-white px-8 py-3 rounded-full font-bold">احجز موعدك الأول</button>
            </div>
          ) : (
            <div className="space-y-6">
              {appointments.map((apt) => (
                <motion.div
                  key={apt.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100 hover:shadow-xl transition-all group"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <span className={`px-4 py-1.5 rounded-full text-xs font-bold ${getStatusColor(apt.status)}`}>
                          {getStatusLabel(apt.status)}
                        </span>
                        <h3 className="text-xl font-bold text-gray-900">{apt.serviceName}</h3>
                      </div>
                      <div className="flex flex-wrap gap-6 text-gray-500">
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Calendar className="h-4 w-4" />
                          <span>{apt.date}</span>
                        </div>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Clock className="h-4 w-4" />
                          <span>{apt.time}</span>
                        </div>
                      </div>
                      {apt.notes && (
                        <div className="bg-gray-50 p-4 rounded-xl text-sm italic text-gray-600 flex items-start space-x-3 space-x-reverse">
                          <FileText className="h-4 w-4 mt-0.5 text-gray-400" />
                          <p>{apt.notes}</p>
                        </div>
                      )}
                    </div>
                    
                    {apt.status === 'pending' && (
                      <button
                        onClick={() => cancelAppointment(apt.id!)}
                        className="bg-red-50 text-red-500 px-6 py-3 rounded-xl font-bold flex items-center justify-center hover:bg-red-500 hover:text-white transition-all space-x-2 space-x-reverse"
                      >
                        <Trash2 className="h-5 w-5" />
                        <span>إلغاء الموعد</span>
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-8">
          <h2 className="text-2xl font-bold">السجل الطبي</h2>
          <div className="bg-gray-900 rounded-[2.5rem] p-10 text-white space-y-8 lg:sticky lg:top-32">
            <div className="space-y-2">
              <h3 className="text-teal-400 font-bold">ملاحظات الطبيب</h3>
              <p className="text-gray-400 leading-relaxed">
                {profile?.medicalHistory || 'لم يتم إضافة ملاحظات طبية بعد. سيظهر تاريخ المرضي والتشخيصات هنا بعد زيارتك الأولى.'}
              </p>
            </div>
            <div className="p-6 bg-white/5 rounded-2xl border border-white/10 space-y-4">
              <h4 className="font-bold">نصيحة الطبيب لهذا اليوم:</h4>
              <p className="text-sm text-gray-300">استخدم خيط الأسنان يومياً قبل النوم للحفاظ على لثة صحية ومنع التسوس بين الأسنان.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
