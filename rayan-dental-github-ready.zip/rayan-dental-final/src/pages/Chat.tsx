import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, where, doc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import { ChatMessage } from '../types';
import { Send, User, MessageCircle } from 'lucide-react';

export default function Chat() {
  const { user, profile, isAdmin } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Each patient has their own chat room. Admin sees their own chat for now.
  // In a full implementation, admin would select from a list of patient chats.
  const chatId = user ? `chat_${user.uid}` : null;

  useEffect(() => {
    if (!user || !chatId) return;
    const q = query(
      collection(db, 'chats', chatId, 'messages'),
      orderBy('createdAt', 'asc')
    );
    return onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ChatMessage)));
    });
  }, [chatId, user]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !user || !chatId) return;

    const text = input;
    setInput('');
    
    try {
      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        senderId: user.uid,
        text,
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 flex flex-col h-[80vh]">
      <div className="bg-white rounded-[3rem] shadow-2xl flex flex-col flex-grow overflow-hidden border border-gray-100">
        <div className="bg-teal-600 p-8 text-white flex items-center space-x-4 space-x-reverse shrink-0">
          <div className="bg-white/20 p-3 rounded-2xl">
            <MessageCircle className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{isAdmin ? 'تواصل مع المريض' : 'تواصل مع العيادة'}</h1>
            <p className="text-teal-100 text-sm">{isAdmin ? 'رد على استفسارات المرضى' : 'فريقنا الطبي متاح للرد على استفساراتك'}</p>
          </div>
        </div>

        <div className="flex-grow overflow-y-auto p-8 space-y-4 bg-gray-50/50">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.senderId === user?.uid ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[70%] p-4 rounded-3xl ${
                    msg.senderId === user?.uid
                      ? 'bg-teal-500 text-white rounded-tr-none'
                      : 'bg-white text-gray-800 shadow-sm rounded-tl-none border border-gray-100'
                  }`}
                >
                  <p className="text-sm md:text-base leading-relaxed">{msg.text}</p>
                  <p className={`text-[10px] mt-1 opacity-60 ${msg.senderId === user?.uid ? 'text-right' : 'text-left'}`}>
                    {msg.createdAt?.toDate ? msg.createdAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '...'}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          <div ref={scrollRef} />
        </div>

        <form onSubmit={sendMessage} className="p-6 bg-white border-t border-gray-100 flex items-center space-x-4 space-x-reverse shrink-0">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="اكتب رسالتك هنا..."
            className="flex-grow bg-gray-50 border-transparent rounded-2xl px-6 py-4 focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="bg-teal-600 text-white p-4 rounded-2xl hover:bg-teal-700 transition-all shadow-lg shadow-teal-200 disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            <Send className="h-6 w-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform rtl:-scale-x-100" />
          </button>
        </form>
      </div>
    </div>
  );
}
