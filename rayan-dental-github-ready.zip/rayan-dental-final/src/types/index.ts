export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  role: 'patient' | 'admin';
  medicalHistory?: string;
  createdAt: string;
}

export interface Appointment {
  id?: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  serviceId: string;
  serviceName: string;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  notes?: string;
  updatedAt?: string;
}

export interface DentalService {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  price: number;
  duration: string;
  icon: string;
}

export interface Testimonial {
  id: string;
  patientName: string;
  contentAr: string;
  rating: number;
  date: string;
}

export interface GalleryItem {
  id: string;
  imageUrl: string;
  titleAr: string;
  category: 'facility' | 'team' | 'treatment';
}

export interface ChatMessage {
  id?: string;
  senderId: string;
  text: string;
  createdAt: any;
}
