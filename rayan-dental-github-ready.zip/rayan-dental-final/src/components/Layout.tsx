import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Calendar, User, ShieldCheck, LogOut, MessageSquare, Instagram, Facebook, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../hooks/useAuth';
import { signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const { user, profile, isAdmin } = useAuth();
  const location = useLocation();

  const navItems = [
    { name: 'الرئيسية', path: '/' },
    { name: 'خدماتنا', path: '/#services' },
    { name: 'معرض الصور', path: '/#gallery' },
    { name: 'آراء المرضى', path: '/#testimonials' },
    { name: 'اتصل بنا', path: '/#contact' },
  ];

  return (
    <div dir="rtl" className="min-h-screen flex flex-col font-sans">
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <Link to="/" className="flex items-center space-x-2 space-x-reverse group">
              <span className="text-2xl font-bold text-gray-900 tracking-tight">Rayan Dental Care</span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8 space-x-reverse">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className="text-gray-600 hover:text-teal-600 font-medium transition-colors"
                >
                  {item.name}
                </Link>
              ))}
              
              <div className="flex items-center space-x-4 space-x-reverse border-r pr-8 border-gray-200">
                {isAdmin && (
                  <Link to="/admin" className="text-teal-600 font-bold flex items-center hover:bg-teal-50 px-4 py-2 rounded-xl transition-all">
                    <ShieldCheck className="ml-2 h-5 w-5" />
                    لوحة الإدارة
                  </Link>
                )}
                <Link
                  to="/booking"
                  className="bg-teal-600 text-white px-6 py-2.5 rounded-full font-semibold hover:bg-teal-700 transition-all shadow-lg shadow-teal-200"
                >
                  حجز موعد الآن
                </Link>
                {user && (
                   <button onClick={() => signOut(auth)} title="تسجيل الخروج" className="p-2 hover:bg-red-50 text-red-500 rounded-full transition-colors">
                    <LogOut className="h-5 w-5" />
                  </button>
                )}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-600 hover:text-gray-900 p-2"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </nav>

        {/* Mobile menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden bg-white border-b border-gray-100 absolute top-20 left-0 right-0 shadow-xl"
            >
              <div className="px-4 pt-2 pb-6 space-y-1">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className="block px-3 py-4 text-base font-medium text-gray-700 hover:text-teal-600 hover:bg-teal-50 rounded-lg"
                  >
                    {item.name}
                  </Link>
                ))}
                <Link
                  to="/booking"
                  onClick={() => setIsMenuOpen(false)}
                  className="block w-full text-center px-3 py-4 text-base font-bold text-white bg-teal-600 rounded-lg"
                >
                  حجز موعد الآن
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="flex-grow pt-20">
        {children}
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-2xl font-bold mb-6">عيادة د/ محمد ريان</h2>
              <p className="text-gray-400 max-w-sm">
                نحن صناع الابتسامة. نقدم أفضل خدمات طب الأسنان في الإسكندرية منذ سنوات، ملتزمون بالجودة والرعاية الفائقة لكل مريض.
              </p>
              <div className="flex items-center gap-4 mt-8">
                <a 
                  href="https://www.facebook.com/share/1CjdFykLV3/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#1877F2] transition-colors"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a 
                  href="https://www.instagram.com/rayan_dental_care?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#E4405F] transition-colors"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a 
                  href="https://wa.me/201550809980" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#25D366] transition-colors"
                >
                  <MessageSquare className="h-5 w-5 text-white" />
                </a>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-6">اتصل بنا</h3>
              <ul className="space-y-4 text-gray-400">
                <li className="flex items-center space-x-3 space-x-reverse">
                  <Phone className="h-5 w-5 text-teal-400" />
                  <span>01550809980</span>
                </li>
                <li>الإسكندرية، سموحة</li>
                <li>خلف نادي النصر، عماير المستشارين</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-6">ساعات العمل</h3>
              <ul className="space-y-2 text-gray-400">
                <li className="flex justify-between">
                  <span>السبت - الخميس:</span>
                  <span>3:00 م - 9:00 م</span>
                </li>
                <li className="flex justify-between text-red-400">
                  <span>الجمعة:</span>
                  <span>عطلة</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-500">
            <p className="mb-4">© {new Date().getFullYear()} عيادة الدكتور محمد ريان. جميع الحقوق محفوظة.</p>
            <Link to="/login" className="text-gray-700 hover:text-gray-600 text-xs transition-colors">دخول الإدارة</Link>
          </div>
        </div>
      </footer>
      
      {/* Floating Actions */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-4 z-40">
        {!isAdmin && (
          <>
            <a 
              href="https://wa.me/201550809980" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center translate-y-0"
              title="تواصل عبر واتساب"
            >
              <MessageCircle className="h-6 w-6" />
            </a>
            <Link 
              to="/chat" 
              className="bg-teal-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center"
              title="الدردشة المباشرة"
            >
              <MessageSquare className="h-6 w-6" />
            </Link>
          </>
        )}
      </div>
    </div>
  );
}
