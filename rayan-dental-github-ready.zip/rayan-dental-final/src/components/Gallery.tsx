import React from 'react';
import { motion } from 'motion/react';

const galleryItems = [
  {
    title: 'غرفة الفحص المتقدمة',
    category: 'الفروع',
    image: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=800'
  },
  {
    title: 'أطباؤنا في خدمتكم',
    category: 'الفريق',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=800'
  },
  {
    title: 'رعاية طبية فائقة',
    category: 'الفريق',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=800'
  },
  {
    title: 'تقنيات زراعة حديثة',
    category: 'الخدمات',
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80&w=800'
  }
];

export default function Gallery() {
  return (
    <section id="gallery" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 scroll-mt-24">
      <div className="text-center mb-16 space-y-4">
        <span className="text-teal-600 font-bold uppercase tracking-wider">جولة في عيادتنا</span>
        <h2 className="text-4xl font-extrabold text-gray-900">معرض الصور</h2>
        <div className="w-20 h-1.5 bg-teal-500 mx-auto rounded-full" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-5xl mx-auto">
        {galleryItems.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="group relative overflow-hidden rounded-[2.5rem] h-80 shadow-lg"
          >
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-8 text-right">
              <span className="text-teal-400 text-sm font-bold mb-2">{item.category}</span>
              <h3 className="text-white text-xl font-bold">{item.title}</h3>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
