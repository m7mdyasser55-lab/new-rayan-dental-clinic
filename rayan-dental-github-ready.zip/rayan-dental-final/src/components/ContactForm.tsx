import React, { useState } from 'react';
import { Send, MapPin, Phone, Mail } from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

export default function ContactForm() {
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      // Write directly to Firestore — no server required
      await addDoc(collection(db, 'messages'), {
        ...formData,
        createdAt: serverTimestamp(),
      });
      setSent(true);
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setSent(false), 4000);
    } catch (err) {
      console.error('Message error:', err);
      setError('عذراً، حدث خطأ. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
      <div className="space-y-8 text-right">
        <div className="flex items-start space-x-4 space-x-reverse">
          <div className="bg-teal-100 p-4 rounded-2xl shrink-0">
            <MapPin className="h-6 w-6 text-teal-600" />
          </div>
          <div>
            <h4 className="font-bold text-gray-900">موقعنا</h4>
            <p className="text-gray-600">الإسكندرية، سموحة، خلف نادي النصر، عماير المستشارين</p>
          </div>
        </div>
        <div className="flex items-start space-x-4 space-x-reverse">
          <div className="bg-teal-100 p-4 rounded-2xl shrink-0">
            <Phone className="h-6 w-6 text-teal-600" />
          </div>
          <div>
            <h4 className="font-bold text-gray-900">اتصل بنا</h4>
            <a href="tel:01550809980" className="text-gray-600 hover:text-teal-600 transition-colors">01550809980</a>
          </div>
        </div>
        <div className="flex items-start space-x-4 space-x-reverse">
          <div className="bg-teal-100 p-4 rounded-2xl shrink-0">
            <Mail className="h-6 w-6 text-teal-600" />
          </div>
          <div>
            <h4 className="font-bold text-gray-900">البريد الإلكتروني</h4>
            <a href="mailto:rayandentalcare170@gmail.com" className="text-gray-600 hover:text-teal-600 transition-colors break-all">
              rayandentalcare170@gmail.com
            </a>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-gray-100">
        <form onSubmit={handleSubmit} noValidate className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">الاسم *</label>
            <input
              required
              type="text"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">البريد الإلكتروني *</label>
            <input
              required
              type="email"
              value={formData.email}
              onChange={e => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none text-left"
              dir="ltr"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">الرسالة *</label>
            <textarea
              required
              rows={4}
              value={formData.message}
              onChange={e => setFormData({ ...formData, message: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 border-transparent rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all outline-none resize-none"
            />
          </div>

          {error && <p className="text-sm text-red-500 text-right">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gray-900 text-white py-4 rounded-xl font-bold flex items-center justify-center space-x-2 space-x-reverse hover:bg-black transition-all active:scale-95 disabled:opacity-50"
          >
            {loading ? (
              <span>جاري الإرسال...</span>
            ) : sent ? (
              <span>✓ تم الإرسال بنجاح!</span>
            ) : (
              <>
                <Send className="h-5 w-5" />
                <span>إرسال الرسالة</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
